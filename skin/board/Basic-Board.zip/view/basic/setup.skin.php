<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// input의 name을 boset[배열키] 형태로 등록

?>

<table>
<caption>내용설정</caption>
<colgroup>
	<col>
</colgroup>
<thead>
<tr>
	<th>본 스킨에는 개별 스킨설정 항목이 없습니다.</th>
</tr>
</thead>
</table>
