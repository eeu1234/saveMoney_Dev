<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if($is_category) 
	include_once($board_skin_path.'/category.skin.php'); // 카테고리

?>
