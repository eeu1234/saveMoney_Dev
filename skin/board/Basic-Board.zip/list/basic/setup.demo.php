<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

//데모설정값
$board['bo_page_rows'] = 24;
$board['bo_mobile_page_rows'] = 12;
$board['bo_subject_len'] = 40;
$board['bo_mobile_subject_len'] = 40;

?>